const products = [
  {name:"Wireless Headphones",cat:"Tech",icon:"◉",price:"$79.99"},
  {name:"Mechanical Keyboard",cat:"Tech",icon:"⌨",price:"$129.99"},
  {name:"Smart Watch",cat:"Tech",icon:"▣",price:"$149.99"},
  {name:"USB-C Charging Hub",cat:"Tech",icon:"▤",price:"$29.99"},
  {name:"Everyday Hoodie",cat:"Clothing",icon:"◇",price:"$39.99"},
  {name:"Classic Sneakers",cat:"Clothing",icon:"◒",price:"$89.99"},
  {name:"Sports Duffel Bag",cat:"Sports",icon:"⬡",price:"$34.99"},
  {name:"Indoor Basketball",cat:"Sports",icon:"◉",price:"$49.95"},
  {name:"Desk Lamp",cat:"Other",icon:"◐",price:"$24.99"},
  {name:"Insulated Water Bottle",cat:"Other",icon:"▯",price:"$19.99"},
  {name:"Portable Speaker",cat:"Tech",icon:"◉",price:"$59.99"},
  {name:"Everyday Backpack",cat:"Other",icon:"▣",price:"$44.99"}
];

const grid = document.getElementById("productGrid");

function renderProducts(filter="All"){
  const list = filter === "All" ? products : products.filter(p => p.cat === filter);
  grid.innerHTML = list.map(p => `
    <article class="product">
      <div class="product-img" aria-hidden="true">${p.icon}</div>
      <div class="product-body">
        <span class="tag">${p.cat.toUpperCase()}</span>
        <h3>${p.name}</h3>
        <div class="stars">★★★★★</div>
        <div class="price">${p.price}</div>
        <div class="affiliate">Demo product — add your approved affiliate link.</div>
        <a class="btn" href="#" data-demo-link="true">CHECK PRICE</a>
      </div>
    </article>
  `).join("");
}
renderProducts();

document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
    button.classList.add("active");
    renderProducts(button.dataset.filter);
  });
});

document.querySelectorAll("[data-filter]").forEach(link => {
  link.addEventListener("click", e => {
    const filter = link.dataset.filter;
    if (!filter) return;
    document.querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b.dataset.filter === filter));
    renderProducts(filter);
  });
});

document.addEventListener("click", e => {
  const link = e.target.closest("[data-demo-link]");
  if (link) {
    e.preventDefault();
    alert("Replace this demo link with your approved affiliate Special Link.");
  }
});

const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
menuToggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", open);
});

document.getElementById("newsletterForm").addEventListener("submit", e => {
  e.preventDefault();
  alert("Newsletter signup is a demo. Connect this form to an email service before launch.");
});

document.getElementById("year").textContent = new Date().getFullYear();

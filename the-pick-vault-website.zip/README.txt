# The Pick Vault

A responsive black-and-gold starter website for a product recommendation / affiliate site.

## Files
- `index.html` — page structure
- `styles.css` — responsive styling
- `script.js` — category filtering, mobile menu, and demo interactions

## Before publishing
1. Replace the demo product names/prices with products you actually feature.
2. Replace each `CHECK PRICE` demo link with the approved affiliate Special Link for the corresponding product.
3. Add your real About, Privacy Policy, Terms, and Affiliate Disclosure pages.
4. Keep the required Amazon Associate disclosure visible and follow the current Amazon Associates Operating Agreement.
5. Do not use Amazon's logos or trademarks unless Amazon's current rules specifically permit the use.

The current product cards intentionally do not contain real affiliate links.
